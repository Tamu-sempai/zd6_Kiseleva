package com.bignerdranch.android.criminalintel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FragmentCrimeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_crime)
    }
}